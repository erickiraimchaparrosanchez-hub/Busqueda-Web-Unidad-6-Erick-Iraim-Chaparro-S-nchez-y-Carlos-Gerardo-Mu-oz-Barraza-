﻿namespace BusquedasWeb;

public record Resultado(
    string Metodo,
    int Posicion,
    int Comparaciones,
    List<string> Pasos,
    string? Extra = null,
    List<string>? Tabla = null);

public static class Busquedas
{
    // Recorre el arreglo elemento por elemento hasta encontrar el valor.
    public static Resultado Secuencial(int[] a, int x)
    {
        var pasos = new List<string>();
        int comparaciones = 0;

        for (int i = 0; i < a.Length; i++)
        {
            comparaciones++;
            bool ok = a[i] == x;
            pasos.Add($"Posición {i}: {a[i]} {(ok ? "=" : "≠")} {x}" + (ok ? " → encontrado" : ""));
            if (ok) return new("Búsqueda secuencial", i, comparaciones, pasos);
        }
        return new("Búsqueda secuencial", -1, comparaciones, pasos);
    }

    // Requiere arreglo ordenado: se ordena una copia y se divide el rango a la mitad en cada paso.
    public static Resultado Binaria(int[] datos, int x)
    {
        var a = (int[])datos.Clone();
        Array.Sort(a);
        var pasos = new List<string>();
        string extra = "Arreglo ordenado: " + string.Join(", ", a) + " (la posición es sobre este arreglo)";
        int bajo = 0, alto = a.Length - 1, comparaciones = 0;

        while (bajo <= alto)
        {
            int medio = bajo + (alto - bajo) / 2;
            comparaciones++;

            if (a[medio] == x)
            {
                pasos.Add($"Rango [{bajo}..{alto}], centro {medio}: {a[medio]} = {x} → encontrado");
                return new("Búsqueda binaria", medio, comparaciones, pasos, extra);
            }
            if (a[medio] < x)
            {
                pasos.Add($"Rango [{bajo}..{alto}], centro {medio}: {a[medio]} < {x} → seguir en la mitad derecha");
                bajo = medio + 1;
            }
            else
            {
                pasos.Add($"Rango [{bajo}..{alto}], centro {medio}: {a[medio]} > {x} → seguir en la mitad izquierda");
                alto = medio - 1;
            }
        }
        return new("Búsqueda binaria", -1, comparaciones, pasos, extra);
    }

    // Tabla hash con encadenamiento: h(k) = k mod m. Se calcula la cubeta y solo se revisa esa.
    public static Resultado Hash(int[] datos, int x)
    {
        int m = Math.Max(5, datos.Length);
        int H(int k) => ((k % m) + m) % m;

        var tabla = new List<(int Valor, int Indice)>?[m];
        for (int i = 0; i < datos.Length; i++)
        {
            int h = H(datos[i]);
            tabla[h] ??= new();
            tabla[h]!.Add((datos[i], i));
        }

        var pasos = new List<string>();
        int cubeta = H(x), comparaciones = 0, posicion = -1;
        pasos.Add($"h({x}) = {x} mod {m} = {cubeta}");

        if (tabla[cubeta] is null)
        {
            pasos.Add($"La cubeta {cubeta} está vacía → no encontrado");
        }
        else
        {
            foreach (var (valor, indice) in tabla[cubeta]!)
            {
                comparaciones++;
                bool ok = valor == x;
                pasos.Add($"Cubeta {cubeta}: {valor} {(ok ? "=" : "≠")} {x}" + (ok ? " → encontrado" : ""));
                if (ok) { posicion = indice; break; }
            }
        }

        var vista = tabla
            .Select((c, k) => $"[{k}]  " + (c is null ? "vacía" : string.Join(" → ", c.Select(e => e.Valor))))
            .ToList();

        return new("Búsqueda por función hash", posicion, comparaciones, pasos,
                   $"Tabla de tamaño {m}, h(k) = k mod {m}", vista);
    }
}